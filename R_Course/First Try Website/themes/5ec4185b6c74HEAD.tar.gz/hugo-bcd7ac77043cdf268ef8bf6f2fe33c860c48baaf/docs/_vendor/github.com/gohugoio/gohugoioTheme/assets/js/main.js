import styles from './../css/main.css';
import './clipboardjs.js'
import './codeblocks.js'
import './docsearch.js'
import './lazysizes.js'
import './menutoggle.js'
import './scrolldir.js'
import './smoothscroll.js'
import './tabs.js'
import './nojs.js'

// TO use jQuery, just call the modules you want
// var $ = require('jquery/src/core');
// require('jquery/src/core/init');
// require('jquery/src/manipulation');

// OR, use all of them
// var $ = require('jquery/src/jquery');

// And write your code
// $('body').append('<p>Jquery is working</p>');
//
