document.documentElement.className = document.documentElement.className.replace(/\bno-js\b/, 'js');
