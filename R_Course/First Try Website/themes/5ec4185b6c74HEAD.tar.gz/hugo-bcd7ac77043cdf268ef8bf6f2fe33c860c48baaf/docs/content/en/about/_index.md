---
title: About Hugo
linktitle: Overview
description: Hugo's features, roadmap, license, and motivation.
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: []
keywords: []
menu:
  docs:
    parent: "about"
    weight: 1
weight: 1
draft: false
aliases: [/about-hugo/,/docs/]
toc: false
---

Hugo is not your average static site generator.
