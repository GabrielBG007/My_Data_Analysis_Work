---
title: lang
package: lang
description: "TODO.."
date: 2021-07-28
categories: [functions]
keywords: [numbers]
menu:
  docs:
    parent: "functions"
signature: ["lang.NumFmt PRECISION NUMBER [OPTIONS [DELIMITER]]"]
aliases: ['/functions/numfmt/']
type: 'template-func'

---

